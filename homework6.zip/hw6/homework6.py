class Attendant:
    def __init__(self,name,company,state,email):
        self.name=name
        self.company=company
        self.state=state
        self.email=email

    def getName(self):
        return self.name
    def getCompany(self):
        return self.company
    def getState(self):
        return self.state
    def getEmail(self):
        return self.email
    def getName_and_email(self):
        print('Name: ',self.name,'. E-mail: ',self.email)

class Conference:
    def __init__(self):
        conflist=[]
        self.conflist=conflist
        readfile=open('attend.txt','r')
        for line in readfile:
            word=line.split()
            firstname=str(word[0])
            lastname=str(word[1])
            company=str(word[2])
            state=str(word[3])
            email=str(word[4])
            name=firstname+' '+lastname
            member=Attendant(name,company,state,email)
            self.conflist.append(member)

        readfile.close()

    def addMember(self,member):
        self.conflist.append(member)
    def deleteMember(self,name):
        for i in self.conflist:
            if i.getName()==name:
                self.conflist.remove(i)
    def infoMember(self,name):
        for i in self.conflist:
            if i.getName()==name:
                print(i.getName(),i.getCompany(),i.getState(),i.getEmail())
    def names_and_emails(self):
        for i in self.conflist:
            i.getName_and_email()
    def member_and_state(self,state):
        for i in self.conflist:
            if i.getState()==state:
                i.getName_and_email()
    def updated(self):
        writefile=open('attend.txt','w')
        for i in self.conflist:
            print(i.getName(),' ',i.getCompany(),' ',i.getState(),' ',i.getEmail(),file=writefile)

        writefile.close()

def main():
    projectfile=open('attend.txt','r')
    for i in range(4):
        line=projectfile.readline()
        print(line)
    projectfile.close()
    print('Welcome to CS Conference!\n Type (add) to input a new member\n Type (delete) to remove a member\n Type (info) to display member info\n Type (members) to display all members\n Type (province) to show members of same state')
    print('\n Type (end) to end the program.')
    members=Conference()
    option=input('Enter an option: ')
    while option!='end':
        if option=='add':
            name=input('Enter member name: ')
            company=input('Enter member company: ')
            state=input('Enter member state: ')
            email=input('Enter member email: ')
            member=Attendant(name,company,state,email)
            members.addMember(member)
            print('Member has been successfully added!')
        elif option=='delete':
            name=input('Enter member name: ')
            members.deleteMember(name)
            print('Member has been successfully deleted')
        elif option=='info':
            name=input('Enter member name: ')
            members.infoMember(name)
        elif option=='members':
            members.names_and_emails()
        elif option=='province':
            state=input('Enter member state/province: ')
            members.member_and_state(state)
        '''else:'''
        option=input('Enter an appropriate option.')
        members.updated()
    if option=='end':
        print('You are done. Goodbye!')

main()
        
        
            
    
